<html>
  <head>
    <meta name="tipo_contenido" content="text/html;" http-equiv="content-type" charset="utf-8">
	<title>Preguntas</title>
    <link rel='stylesheet' type='text/css' href='estilos/style.css' />
	<link rel='stylesheet' 
		   type='text/css' 
		   media='only screen and (min-width: 530px) and (min-device-width: 481px)'
		   href='estilos/wide.css' />
	<link rel='stylesheet' 
		   type='text/css' 
		   media='only screen and (max-width: 480px)'
		   href='estilos/smartphone.css' />
  </head>
  <body>
  <div id='page-wrap'>
	<header class='main' id='h1'>
		<span class="right"><a href="registro">Registrarse</a></span>
      		<span class="right"><a href="login">Login</a></span>
      		<span class="right" style="display:none;"><a href="/logout">Logout</a></span>
		<h2>Quiz: el juego de las preguntas</h2>
    </header>
	<nav class='main' id='n1' role='navigation'>
		<span><a href='layout.html'>Inicio</a></span>
		<span><a href='pregunta.html'>Preguntas</a></span>
		<span><a href='creditos.html'>Creditos</a></span>
	</nav>
    <section class="main" id="s1">
    
	<div>
		<?php

    $link = mysqli_connect("localhost","root","root","quiz");
	
	$nombre_img = $_FILES['archivos']['name'];

 
	//Si existe imagen y tiene un tamaño correcto
	if (($nombre_img == !NULL)) 
	{
	   //indicamos los formatos que permitimos subir a nuestro servidor
	   if (($_FILES["archivos"]["type"] == "image/gif")
	   || ($_FILES["archivos"]["type"] == "image/jpeg")
	   || ($_FILES["archivos"]["type"] == "image/jpg")
	   || ($_FILES["archivos"]["type"] == "image/png"))
	   {
		  // Ruta donde se guardarán las imágenes que subamos
		  $directorio = $_SERVER['DOCUMENT_ROOT'].'Lab2BSW/imagenes/';
		  // Muevo la imagen desde el directorio temporal a nuestra ruta indicada anteriormente
		  move_uploaded_file($_FILES['archivos']['tmp_name'],$directorio.$nombre_img);
		} 
		else 
		{
		   //si no cumple con el formato
		   echo "No se puede subir una imagen con ese formato ";
		}
	}
    
    $sql = "INSERT INTO preguntas VALUES ('','$_POST[textoEmail]','$_POST[textoPregunta]','$_POST[textoCorrecto]','$_POST[textoIncorrecto1]','$_POST[textoIncorrecto2]','$_POST[textoIncorrecto3]','$_POST[textoComplejidad]','$_POST[textoTema]','$nombre_img')";
    if (!mysqli_query($link,$sql)){
        die ("Pulsa en REPETIR para intentarlo de nuevo </br> <input type='button' value = 'REPETIR' onclick='history.back()'>");
		
    }
	echo "Añadida una nueva fila </br>";
    echo "Pulsa aqui para ver todos los datos: ";
    echo '</br>';
    echo '<a href="verPreguntas.php">Ver preguntas</a>';
    echo '</br>';
    echo "Pulsa aqui para volver a insertar otra pregunta: ";
    echo '<input type="button" value="VOLVER ATRÁS" name="atras" onclick="history.back()" />';
mysqli_close($link);

    ?>
	
	</div>
    </section>
	<footer class='main' id='f1'>
		<p><a href="http://es.wikipedia.org/wiki/Quiz" target="_blank">Que es un Quiz?</a></p>
		<a href='https://github.com'>Link GITHUB</a>
	</footer>
  </div>
  
</html>

